﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_GuiBasedApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //acts as my main method
        {
            string name = GetName("Please enter your name:");
            string saying = GetName("Please enter your favorite saying:");
            DisplayMessage(name, saying);

        }
        private string GetName(string prompt)
        {
            using (var dialog = new InputDialog(prompt))
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.InputValue;
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        private void DisplayMessage(string name, string saying)
        {
            MessageBox.Show($"<><><><><><><><><><><>\nName is:<{name}>\n<><><><><><><><><><><><><><>\n Fav Saying is:<{saying}>\n <><><><><><><><><><><><><>", "Message Display");
        }

    }

public class InputDialog : Form
{
    private Label promptLabel;
    private TextBox inputTextBox;
    private Button okButton;

    public string InputValue => inputTextBox.Text;

    public InputDialog(string prompt)
    {
        InitializeComponents();
        promptLabel.Text = prompt;
    }

    private void InitializeComponents()
    {
        promptLabel = new Label
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(10)
        };

        inputTextBox = new TextBox
        {
            Dock = DockStyle.Top,
            Padding = new Padding(10)
        };

        okButton = new Button
        {
            Dock = DockStyle.Bottom,
            Text = "OK",
            DialogResult = DialogResult.OK
        };

        Controls.Add(inputTextBox);
        Controls.Add(promptLabel);
        Controls.Add(okButton);

        AcceptButton = okButton;
        CancelButton = okButton;

        Text = "Input Dialog";
        Size = new System.Drawing.Size(300, 150);
    }
}
}
